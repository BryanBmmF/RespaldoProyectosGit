package interfaces;

/**
 * Interfaces
 * @author jose - 27.02.2017 
 * @Title: Frenar
 * @Description: description
 *
 * Changes History
 */
public interface Frenar {
	
	public void reducirVelocidad();
}
