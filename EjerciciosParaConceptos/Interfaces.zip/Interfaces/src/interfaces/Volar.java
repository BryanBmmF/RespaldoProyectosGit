package interfaces;

/**
 * Interfaces
 * @author jose - 27.02.2017 
 * @Title: Volar
 * @Description: description
 *
 * Changes History
 */
public interface Volar {
	public void aumentarAltura(int metros);
	public void aterrizar();
}
