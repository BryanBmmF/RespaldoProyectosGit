package interfaces;

/**
 * Interfaces
 * @author jose - 27.02.2017 
 * @Title: Desplazar
 * @Description: description
 *
 * Changes History
 */
public interface Desplazar {
	
	public static final String UNIDAD_MEDIDA = "mtrs";
	
	public void recorrerDistancia(int metros);
}