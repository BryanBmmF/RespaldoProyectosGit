package animales;

/**
 * Interfaces
 * @author jose - 27.02.2017 
 * @Title: Animal
 * @Description: description
 *
 * Changes History
 */
public class Animal {
	private boolean comeDeTodo;
	
	public void comer(String comida) {
		System.out.println("Estoy comiendo: " + comida);
	}
	
}