package animales;

/**
 * Interfaces
 * @author jose - 06.03.2018 
 * @Title: Coral
 * @Description: description
 *
 * Changes History
 */
public class Coral extends Animal {
	
}