package taller;

public class Vehiculo {
	int cantidadLlantas;
	String tipoMotor;
	String tipoAceite;
	
	public Vehiculo(int cantidadLlantas, String tipoMotor, String tipoAceite) {
		this.cantidadLlantas = cantidadLlantas;
		this.tipoMotor = tipoMotor;
		this.tipoAceite = tipoAceite;
	}
	
	void cambioAceite() {
		System.out.println("Ya se cambio aceite");
	}
	
	void cambioLlantas() {
		System.out.println("Ya se cambio llantas");
	}
	
	public int verCantidadLlantas() {
		return this.cantidadLlantas;
	}
	
	
}
