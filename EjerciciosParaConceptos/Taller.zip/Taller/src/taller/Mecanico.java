package taller;

/**
 * Taller
 * @author jose - 21.02.2018 
 * @Title: Mecanico
 * @Description: description
 *
 * Changes History
 */
public class Mecanico {
	private String CUI;
	private String nombre;
	private Vehiculo asignado;
	private String apellido;
	
	public Mecanico(String nuevoCUI, String nuevoNombre,
		   String nuevoApellido) {
		this.CUI = nuevoCUI;
		this.nombre = nuevoNombre;
		this.apellido = nuevoApellido;
		//this.verDatos();
	}
	
	public Mecanico(String CUI) {
		this.CUI = CUI;
	}
	
	void especificarDatos(String nuevoCUI, String nuevoNombre,
		   String nuevoApellido) {
		this.CUI = nuevoCUI;
		this.nombre = nuevoNombre;
		this.apellido = nuevoApellido;
	}
	
	void asignarVehiculo(Vehiculo vehiculo) {
		this.asignado = vehiculo;
		System.out.println("vehiculo asignado con el numero de llantas: "
			   + asignado.verCantidadLlantas());
	}
	
	void cambiarNombre(String nuevoNombre) {
		this.nombre = nuevoNombre;
	}
	
	void verDatos() {
		System.out.println("CUI: " + CUI);
		System.out.println("nombre: " + nombre);
		System.out.println("apellido: " + apellido);
	}

}